from pathlib import Path
import os
import pymysql

# Install pymysql to act as MySQLdb
pymysql.install_as_MySQLdb()

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'django-insecure-cbad6_5bqkdsl($tki)r20ko^@+zft5-u^8)84zgt)910-(5xv'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

# List of allowed hosts for your app. Add actual hostnames/IPs for production.
ALLOWED_HOSTS = ['localhost','127.0.0.1']

# Application definition
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'second',  
    'rest_framework',
    'corsheaders',
    
]

MIDDLEWARE = [
    
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

CORS_ALLOWED_ORIGINS = [
    # "http://localhost:52542",  # For testing with the Django app running on the same machine
    # "http://127.0.0.1:8000",
    'http://localhost:8000',  # Add your Flutter app's origin here
    'http://192.168.x.x:8000',  # If running on a device, use the actual local network IP address
]

CORS_ALLOW_ALL_ORIGINS = True

ROOT_URLCONF = 'dm1.urls'

# Templates settings
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'template')],  # Adjust template path if needed
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'dm1.wsgi.application'

# Database settings (ensure MySQL is properly set up)
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'data',
        'USER': 'root',  # Make sure this matches the MySQL user
        'PASSWORD': 'demo@123',  # Ensure this is correct
        'HOST': 'localhost',  # Or the appropriate MySQL server IP if it's remote
        'PORT': '3306',  # Default MySQL port
    }
}


# Password validation (optional, customize as per your needs)
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# Localization settings
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_TZ = True

# Static files (CSS, JavaScript, Images)
STATIC_URL = '/static/'

# Add the directories where Django will look for static files
STATICFILES_DIRS = [BASE_DIR / 'static']

# Default primary key field type (default value)
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'


# Redirect settings for login/logout
LOGIN_REDIRECT_URL = 'home'  # Redirects to home page after successful login
LOGOUT_REDIRECT_URL = 'admin_login'  # Redirects to login page after logout
LOGIN_URL = 'admin_login'  # Default login page
