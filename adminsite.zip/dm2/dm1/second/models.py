from django.db import models
from django.contrib.auth.hashers import make_password

class User(models.Model):
    username = models.CharField(max_length=100, unique=True)
    password = models.CharField(max_length=255)

    def save(self, *args, **kwargs):
        # Hash the password before saving
        self.password = make_password(self.password)
        super(User, self).save(*args, **kwargs)

    def __str__(self):
        return self.username

class ElderUser(models.Model):
    firstname = models.CharField(max_length=30,default="abc")
    lastname = models.CharField(max_length=30,default="abc")
    username = models.CharField(max_length=30,unique=True)
    password = models.CharField(max_length=100)  
    confirm_password = models.CharField(max_length=100,default="d111")  
    dob = models.DateField(default="2003-10-22")  
    phone_no = models.BigIntegerField(default=9625415223)  
    email = models.EmailField(max_length=30,default="d@gmail.com")  
    em_no = models.BigIntegerField(default=1234564567)  
    doc_no = models.IntegerField(default=1234567896) 
    address = models.CharField(max_length=100, null=True, blank=True,default="aaa")  

    # def save(self, *args, **kwargs):
    #     # Hash the password before saving
    #     self.password = make_password(self.password)
    #     super(User, self).save(*args, **kwargs)
    
    def __str__(self):
        return self.username

class ServiceUser(models.Model):
    sid = models.AutoField(primary_key=True)  
    firstname = models.CharField(max_length=30)
    lastname = models.CharField(max_length=30)
    username = models.CharField(max_length=30)
    password = models.CharField(max_length=100) 
    confirm_password = models.CharField(max_length=100)  
    dob = models.DateField()  
    phone_no = models.BigIntegerField() 
    email = models.EmailField(max_length=30) 
    address = models.CharField(max_length=100, null=True, blank=True)  

    def __str__(self):
        return self.username

class ServiceCategory(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


