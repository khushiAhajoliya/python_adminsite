# services/forms.py

from django import forms
from .models import*

class ServiceCategoryForm(forms.ModelForm):
    class Meta:
        model = ServiceCategory
        fields = ['name']
        
class ServiceProviderForm(forms.ModelForm):
    class Meta:
        model = ServiceUser
        fields=['firstname','lastname','username','dob','phone_no','email','address']

class EldermanForm(forms.ModelForm):
    class Meta:
        model=ElderUser
        fields=['firstname','lastname','username','dob','phone_no','email','address','em_no']
