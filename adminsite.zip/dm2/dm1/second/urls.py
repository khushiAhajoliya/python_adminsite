from django.contrib import admin
from django.urls import path
from django.contrib.auth import views as auth_views
from . import views


urlpatterns = [
    path('admin/', admin.site.urls),
    path('home', views.home, name='home'),

    # Login and Logout URLs
    path('', auth_views.LoginView.as_view(template_name='admin_login.html'), name='admin_login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),

    # Elderman Management
    path('manageem', views.manageem, name="manageem"),
    path('api/create_euser/',views.create_euser, name='create_euser'),
    path('update/<int:pk>/', views.update_elder, name='update_elder'),
    path('delete/<int:pk>/', views.delete_elder, name='delete_elder'),

    # Service Provider Management
    path('manage-service-provider/', views.managesp, name='managesp'),
    path('api/create_suser/',views.create_suser, name='create_suser'),
    path('update-service-provider/<int:pk>/', views.update_service_p, name='update_service_p'),
    path('delete-service-provider/<int:pk>/', views.delete_service_p, name='delete_service_p'),

    # Services Management
    path('services', views.services, name='services'),
    path('add/', views.add_service_category, name='add_service_category'),
    path('update_service_category/<int:pk>/', views.update_service_category, name='update_service_category'),
    path('delete_service_category/<int:pk>/', views.delete_service_category, name='delete_service_category'),

    path('feedback/', views.feedback_view, name='feedback'),

    path('user/', views.user_list, name='user_list'),
]
