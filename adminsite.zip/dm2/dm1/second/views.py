
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, logout, authenticate
from .models import ServiceUser, ElderUser, ServiceCategory,User
from django.db import connection
from .forms import *

from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import User,ElderUser,ServiceUser
from .serializers import UserSerializer,ElderSerializer,ServiseSerializer

def home(request):
    if not request.user.is_authenticated:
        return redirect('admin_login')

    elderman_count = ElderUser.objects.count()
    service_provider_count = ServiceUser.objects.count()
    service_count = ServiceCategory.objects.count()

    context = {
        'elderman_count': elderman_count,
        'service_provider_count': service_provider_count,
        'service_count': service_count,
    }
    return render(request, 'home.html', context)

@login_required
def manageem(request):
    euser = ElderUser.objects.all()
    return render(request, 'manageem.html', {'users': euser})

@api_view(['POST'])
def create_euser(request):
    if request.method == 'POST':
        serializer = ElderSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()  # Save the user to the database
            return Response({'message': 'User created successfully'}, status=201)
        return Response(serializer.errors, status=400)

@login_required
def update_elder(request, pk):
    user = get_object_or_404(ElderUser, pk=pk)
    if request.method == 'POST':
        form = EldermanForm(request.POST, instance=user)
        if form.is_valid():
            form.save()
            return redirect('manageem')
    else:
        form = EldermanForm(instance=user)
    return render(request, 'update_elder.html', {'form': form})

@login_required
def delete_elder(request, pk):
    user = get_object_or_404(ElderUser, pk=pk)
    if request.method == 'POST':
        user.delete()
        return redirect('manageem')
    return render(request, 'delete_elder.html', {'user': user})

@login_required
def managesp(request):
    suser = ServiceUser.objects.all()
    return render(request, 'managesp.html', {'users': suser})

@api_view(['POST'])
def create_suser(request):
    if request.method == 'POST':
        serializer = ServiseSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()  # Save the user to the database
            return Response({'message': 'User created successfully'}, status=201)
        return Response(serializer.errors, status=400)
    
@login_required
def update_service_p(request, pk):
    user = get_object_or_404(ServiceUser, pk=pk)
    if request.method == 'POST':
        form = ServiceProviderForm(request.POST, instance=user)
        if form.is_valid():
            form.save()
            return redirect('managesp')
    else:
        form = ServiceProviderForm(instance=user)
    return render(request, 'update_service_p.html', {'form': form})

@login_required
def delete_service_p(request, pk):
    user = get_object_or_404(ServiceUser, pk=pk)
    if request.method == 'POST':
        user.delete()
        return redirect('managesp')
    return render(request, 'delete_service_p.html', {'user': user})

@login_required
def services(request):
    categories = ServiceCategory.objects.all()
    return render(request, 'services.html', {'categories': categories})

@login_required
def add_service_category(request):
    if request.method == 'POST':
        form = ServiceCategoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('services')
    else:
        form = ServiceCategoryForm()
    return render(request, 'add_service_category.html', {'form': form})

@login_required
def update_service_category(request, pk):
    category = get_object_or_404(ServiceCategory, pk=pk)
    if request.method == 'POST':
        form = ServiceCategoryForm(request.POST, instance=category)
        if form.is_valid():
            form.save()
            return redirect('services')
    else:
        form = ServiceCategoryForm(instance=category)
    return render(request, 'update_service_category.html', {'form': form})

@login_required
def delete_service_category(request, pk):
    category = get_object_or_404(ServiceCategory, pk=pk)
    if request.method == 'POST':
        category.delete()
        return redirect('services')
    return render(request, 'delete_service_category.html', {'category': category})

def feedback_view(request):
    with connection.cursor() as cursor:
        cursor.execute("SELECT id, name, email, message, created_at FROM feedback")
        feedback_data = cursor.fetchall()  # Fetch all rows

    # Pass data to the template
    return render(request, 'feedback.html', {'feedback_data': feedback_data})

def user_list(request):
    users = User.objects.all()  # Get all users from the database
    return render(request, 'user_list.html', {'users': users})

@api_view(['POST'])
def create_user(request):
    if request.method == 'POST':
        serializer = UserSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()  # Save the user to the database
            return Response({'message': 'User created successfully'}, status=201)
        return Response(serializer.errors, status=400)