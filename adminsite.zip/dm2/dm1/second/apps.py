from django.apps import AppConfig


class SecondConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'second'
