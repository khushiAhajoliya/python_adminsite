from django.contrib import admin
# from .models import ElderUser
from .models import*

# @admin.register(ElderUser)
# class ElderUserAdmin(admin.ModelAdmin):
#     list_display = ('id', 'firstname', 'lastname', 'username', 'address', 'dob', 'phone_no', 'email', 'em_no', 'doc_no')  # Fields to display in the list view
#     search_fields = ('firstname', 'lastname', 'username', 'email')  # Fields to search in the admin interface
#     list_filter = ('dob', 'email')  # Filter the list based on fields
#     ordering = ('-dob',)  # Order the list by date of birth in descending order
admin.site.register(ElderUser)
admin.site.register(ServiceUser)
admin.site.register(ServiceCategory)
